# IMPÉRIO DIGITAL - Plataforma de Venda de Cursos e CMS

Este projeto é uma solução completa para apresentação e comercialização de cursos de marketing digital com gerenciamento via painel administrativo.

## 🚀 Como Executar o Projeto

### 1. Iniciar o Backend
```bash
cd backend
npm install
node server.js
```
O servidor backend rodará na porta `5000`.

### 2. Iniciar o Frontend
```bash
cd frontend
npm install
npm run dev
```
Abra o navegador no endereço exibido (ex: `http://localhost:5173`).

### 🔐 Acesso Administrativo
- **URL**: `http://localhost:5173/admin`
- **Senha Inicial**: `17`
