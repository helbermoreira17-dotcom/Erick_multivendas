require('dotenv').config();
const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'imperio_digital_secret_key_2026';

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Upload Config
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/\s+/g, '_'))
});
const upload = multer({ storage });

// SQLite Database
const db = new sqlite3.Database('./database.sqlite', (err) => {
  if (err) console.error('Erro ao conectar ao SQLite:', err);
  else console.log('Conectado ao banco SQLite.');
});

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS courses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    description TEXT,
    price REAL,
    old_price REAL,
    discount_percentage INTEGER,
    promo_active INTEGER,
    image TEXT,
    checkout_url TEXT,
    currency TEXT DEFAULT 'R$'
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS faqs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question TEXT,
    answer TEXT
  )`);

  db.get("SELECT * FROM users WHERE username = 'admin'", [], (err, row) => {
    if (!row) {
      const hash = bcrypt.hashSync('17', 10);
      db.run("INSERT INTO users (username, password) VALUES ('admin', ?)", [hash]);
      console.log("Usuário 'admin' criado com a senha inicial '17'.");
    }
  });

  const defaultSettings = {
    theme: JSON.stringify({
      primaryColor: '#0284c7',
      secondaryColor: '#0f172a',
      buttonColor: '#2563eb',
      textColor: '#ffffff',
      bgColor: '#030712',
      cardRadius: '12px'
    }),
    layout: JSON.stringify(['hero', 'benefits', 'courses', 'cta', 'faq']),
    hero: JSON.stringify({
      title: 'Transforme seu conhecimento em novas oportunidades com o Marketing Digital.',
      subtitle: 'Aprenda estratégias validadas para criar, escalar e dominar o mercado digital do zero.',
      buttonText: 'QUERO COMEÇAR AGORA',
      buttonUrl: '#courses',
      bannerUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80'
    }),
    footer: JSON.stringify({
      instagram: 'https://instagram.com/imperiodigital',
      tiktok: 'https://tiktok.com/@imperiodigital',
      whatsapp: 'https://wa.me/5500000000000',
      email: 'contato@imperiodigital.com'
    })
  };

  for (const [k, v] of Object.entries(defaultSettings)) {
    db.run("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", [k, v]);
  }
});

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Acesso negado.' });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Token inválido.' });
    req.user = user;
    next();
  });
};

app.post('/api/login', (req, res) => {
  const { password } = req.body;
  db.get("SELECT * FROM users WHERE username = 'admin'", [], (err, user) => {
    if (err || !user) return res.status(400).json({ error: 'Usuário não encontrado.' });
    if (bcrypt.compareSync(password, user.password)) {
      const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '8h' });
      return res.json({ token });
    }
    res.status(401).json({ error: 'Senha incorreta.' });
  });
});

app.post('/api/change-password', authenticateToken, (req, res) => {
  const { newPassword } = req.body;
  if (!newPassword || newPassword.length < 2) {
    return res.status(400).json({ error: 'Senha inválida.' });
  }
  const hash = bcrypt.hashSync(newPassword, 10);
  db.run("UPDATE users SET password = ? WHERE username = 'admin'", [hash], function(err) {
    if (err) return res.status(500).json({ error: 'Erro ao atualizar senha.' });
    res.json({ message: 'Senha alterada com sucesso.' });
  });
});

app.get('/api/site-data', (req, res) => {
  const data = {};
  db.all("SELECT * FROM settings", [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    rows.forEach(r => data[r.key] = JSON.parse(r.value));

    db.all("SELECT * FROM courses", [], (err, courses) => {
      data.courses = courses || [];
      db.all("SELECT * FROM faqs", [], (err, faqs) => {
        data.faqs = faqs || [];
        res.json(data);
      });
    });
  });
});

app.post('/api/settings', authenticateToken, (req, res) => {
  const { key, value } = req.body;
  db.run("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", [key, JSON.stringify(value)], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ status: 'success' });
  });
});

app.post('/api/courses', authenticateToken, (req, res) => {
  const { title, description, price, old_price, discount_percentage, promo_active, image, checkout_url, currency } = req.body;
  db.run(
    `INSERT INTO courses (title, description, price, old_price, discount_percentage, promo_active, image, checkout_url, currency)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [title, description, price, old_price, discount_percentage, promo_active ? 1 : 0, image, checkout_url, currency || 'R$'],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID });
    }
  );
});

app.put('/api/courses/:id', authenticateToken, (req, res) => {
  const { title, description, price, old_price, discount_percentage, promo_active, image, checkout_url, currency } = req.body;
  db.run(
    `UPDATE courses SET title = ?, description = ?, price = ?, old_price = ?, discount_percentage = ?, promo_active = ?, image = ?, checkout_url = ?, currency = ? WHERE id = ?`,
    [title, description, price, old_price, discount_percentage, promo_active ? 1 : 0, image, checkout_url, currency, req.params.id],
    (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ status: 'updated' });
    }
  );
});

app.delete('/api/courses/:id', authenticateToken, (req, res) => {
  db.run("DELETE FROM courses WHERE id = ?", [req.params.id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ status: 'deleted' });
  });
});

app.post('/api/faqs', authenticateToken, (req, res) => {
  const { question, answer } = req.body;
  db.run("INSERT INTO faqs (question, answer) VALUES (?, ?)", [question, answer], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ id: this.lastID });
  });
});

app.delete('/api/faqs/:id', authenticateToken, (req, res) => {
  db.run("DELETE FROM faqs WHERE id = ?", [req.params.id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ status: 'deleted' });
  });
});

app.post('/api/upload', authenticateToken, upload.single('image'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Nenhum arquivo enviado.' });
  const imageUrl = `http://localhost:${PORT}/uploads/${req.file.filename}`;
  res.json({ url: imageUrl });
});

app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
