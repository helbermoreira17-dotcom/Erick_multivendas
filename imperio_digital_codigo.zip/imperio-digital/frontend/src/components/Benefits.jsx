import React from 'react';
import { BookOpen, Rocket, RefreshCw, Layers, Clock, Target } from 'lucide-react';

const benefitsList = [
  { icon: BookOpen, title: 'Aprenda do zero', desc: 'Conteúdo passo a passo pensado para iniciantes e avançados.' },
  { icon: Rocket, title: 'Aulas práticas', desc: 'Metodologia direto ao ponto com aplicações reais no mercado.' },
  { icon: RefreshCw, title: 'Conteúdo atualizado', desc: 'Aulas renovadas periodicamente de acordo com as tendências.' },
  { icon: Layers, title: 'Acesso aos materiais', desc: 'Templates, frameworks e resumos prontos para download.' },
  { icon: Clock, title: 'Aprenda no seu ritmo', desc: 'Acesso 24/7 de qualquer dispositivo móvel ou computador.' },
  { icon: Target, title: 'Estratégias de marketing', desc: 'Táticas avançadas de vendas, tráfego pago e engajamento.' }
];

export default function Benefits() {
  return (
    <section id="benefits" className="py-20 px-6 bg-slate-950/50 border-y border-slate-900">
      <div className="max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Por que escolher o <span className="gradient-text">Império Digital</span>?</h2>
          <p className="text-slate-400">Tudo o que você precisa para alcançar sua independência no mercado digital.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefitsList.map((b, idx) => {
            const Icon = b.icon;
            return (
              <div key={idx} className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800/80 hover:border-sky-500/50 transition group">
                <div className="w-12 h-12 rounded-xl bg-sky-950 flex items-center justify-center text-sky-400 mb-6 group-hover:scale-110 transition">
                  <Icon size={24} />
                </div>
                <h3 className="text-xl font-bold mb-2 text-white">{b.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{b.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
