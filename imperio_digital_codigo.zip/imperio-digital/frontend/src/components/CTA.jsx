import React from 'react';

export default function CTA({ data }) {
  const hero = data?.hero || {};

  return (
    <section className="py-20 px-6">
      <div className="max-w-5xl mx-auto rounded-3xl bg-gradient-to-r from-sky-900/60 to-blue-900/40 border border-sky-500/30 p-10 md:p-16 text-center relative overflow-hidden blue-glow">
        <h2 className="text-3xl md:text-5xl font-black mb-6 text-white">Está pronto para começar?</h2>
        <p className="text-slate-300 text-lg mb-8 max-w-2xl mx-auto">
          Não deixe sua evolução para amanhã. Acesse agora mesmo nossos conteúdos exclusivos e mude seu jogo no mercado digital.
        </p>
        <a 
          href={hero.buttonUrl || '#courses'} 
          className="inline-block px-10 py-4 rounded-xl bg-white text-slate-950 font-black text-lg hover:bg-slate-100 transition shadow-xl"
        >
          GARANTIR MINHA VAGA
        </a>
      </div>
    </section>
  );
}
