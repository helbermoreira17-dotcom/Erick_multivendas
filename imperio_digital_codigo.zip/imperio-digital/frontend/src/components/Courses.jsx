import React from 'react';

export default function Courses({ data }) {
  const courses = data?.courses || [];

  return (
    <section id="courses" className="py-24 px-6 max-w-7xl mx-auto">
      <div className="text-center max-w-2xl mx-auto mb-16">
        <h2 className="text-3xl md:text-5xl font-black mb-4">Nossos <span className="gradient-text">Treinamentos</span></h2>
        <p className="text-slate-400">Escolha o plano ideal para alavancar os seus resultados hoje mesmo.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {courses.map((c) => (
          <div key={c.id} className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden flex flex-col justify-between hover:border-sky-500/40 transition blue-glow">
            <div>
              <div className="relative h-48 overflow-hidden">
                <img src={c.image} alt={c.title} className="w-full h-full object-cover" />
                {c.promo_active === 1 && (
                  <span className="absolute top-4 right-4 bg-sky-500 text-xs font-black uppercase px-3 py-1 rounded-full text-slate-950">
                    {c.discount_percentage}% OFF
                  </span>
                )}
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-3 text-white">{c.title}</h3>
                <p className="text-slate-400 text-sm mb-6 leading-relaxed">{c.description}</p>
              </div>
            </div>

            <div className="p-6 pt-0">
              <div className="mb-6">
                {c.promo_active === 1 && c.old_price && (
                  <span className="text-sm line-through text-slate-500 mr-2">
                    {c.currency} {c.old_price.toFixed(2)}
                  </span>
                )}
                <span className="text-3xl font-extrabold text-white">
                  {c.currency} {c.price.toFixed(2)}
                </span>
              </div>
              <a
                href={c.checkout_url}
                target="_blank"
                rel="noreferrer"
                className="w-full py-3.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-center block transition shadow-lg shadow-sky-600/20"
              >
                QUERO ESTE CURSO
              </a>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
