import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

export default function FAQ({ data }) {
  const faqs = data?.faqs || [];
  const [openIdx, setOpenIdx] = useState(null);

  return (
    <section id="faq" className="py-20 px-6 max-w-4xl mx-auto">
      <div className="text-center mb-16">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">Perguntas <span className="gradient-text">Frequentes</span></h2>
        <p className="text-slate-400">Tire suas dúvidas antes de dar o próximo passo.</p>
      </div>

      <div className="space-y-4">
        {faqs.map((faq, idx) => (
          <div key={faq.id || idx} className="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden">
            <button
              onClick={() => setOpenIdx(openIdx === idx ? null : idx)}
              className="w-full p-6 text-left font-semibold text-lg flex justify-between items-center text-slate-200 hover:text-white"
            >
              {faq.question}
              <ChevronDown className={`transition-transform duration-200 ${openIdx === idx ? 'rotate-180' : ''}`} />
            </button>
            {openIdx === idx && (
              <div className="px-6 pb-6 text-slate-400 text-sm leading-relaxed border-t border-slate-800/50 pt-4">
                {faq.answer}
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
