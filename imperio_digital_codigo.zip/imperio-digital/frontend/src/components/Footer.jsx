import React from 'react';
import { Instagram, Music, MessageCircle, Mail } from 'lucide-react';

export default function Footer({ data }) {
  const footer = data?.footer || {};

  return (
    <footer id="contact" className="border-t border-slate-900 bg-slate-950 py-12 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
        <div>
          <a href="#" className="text-2xl font-black tracking-wider text-white">
            IMPÉRIO<span className="text-sky-400">DIGITAL</span>
          </a>
          <p className="text-xs text-slate-500 mt-2">Seu conhecimento pode ser o começo de um novo caminho.</p>
        </div>

        <div className="flex items-center gap-6">
          {footer.instagram && (
            <a href={footer.instagram} target="_blank" rel="noreferrer" className="text-slate-400 hover:text-sky-400 transition">
              <Instagram size={22} />
            </a>
          )}
          {footer.tiktok && (
            <a href={footer.tiktok} target="_blank" rel="noreferrer" className="text-slate-400 hover:text-sky-400 transition">
              <Music size={22} />
            </a>
          )}
          {footer.whatsapp && (
            <a href={footer.whatsapp} target="_blank" rel="noreferrer" className="text-slate-400 hover:text-sky-400 transition">
              <MessageCircle size={22} />
            </a>
          )}
          {footer.email && (
            <a href={`mailto:${footer.email}`} className="text-slate-400 hover:text-sky-400 transition">
              <Mail size={22} />
            </a>
          )}
        </div>
      </div>
      <div className="text-center text-xs text-slate-600 mt-8 border-t border-slate-900/60 pt-6">
        © {new Date().getFullYear()} IMPÉRIO DIGITAL. Todos os direitos reservados.
      </div>
    </footer>
  );
}
