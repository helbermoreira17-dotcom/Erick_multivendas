import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';

export default function Header({ data }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 w-full bg-slate-950/80 backdrop-blur-md border-b border-slate-800 z-50">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <a href="#" className="text-2xl font-black tracking-wider text-white flex items-center gap-2">
          <span className="w-4 h-4 rounded-full bg-sky-500 shadow-[0_0_12px_#38bdf8]"></span>
          IMPÉRIO<span className="text-sky-400">DIGITAL</span>
        </a>

        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-300">
          <a href="#home" className="hover:text-sky-400 transition">Início</a>
          <a href="#courses" className="hover:text-sky-400 transition">Cursos</a>
          <a href="#benefits" className="hover:text-sky-400 transition">Benefícios</a>
          <a href="#faq" className="hover:text-sky-400 transition">FAQ</a>
          <a href="#contact" className="hover:text-sky-400 transition">Contato</a>
        </nav>

        <a href="#courses" className="hidden md:inline-flex px-6 py-2.5 rounded-full bg-sky-600 hover:bg-sky-500 text-white font-semibold text-sm transition shadow-lg shadow-sky-600/30">
          Ver cursos
        </a>

        <button className="md:hidden text-slate-300" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {isOpen && (
        <div className="md:hidden bg-slate-900 border-b border-slate-800 px-6 py-6 flex flex-col gap-4 text-slate-300">
          <a href="#home" onClick={() => setIsOpen(false)}>Início</a>
          <a href="#courses" onClick={() => setIsOpen(false)}>Cursos</a>
          <a href="#benefits" onClick={() => setIsOpen(false)}>Benefícios</a>
          <a href="#faq" onClick={() => setIsOpen(false)}>FAQ</a>
          <a href="#contact" onClick={() => setIsOpen(false)}>Contato</a>
          <a href="#courses" onClick={() => setIsOpen(false)} className="mt-2 text-center py-3 bg-sky-600 text-white font-semibold rounded-lg">
            Ver cursos
          </a>
        </div>
      )}
    </header>
  );
}
