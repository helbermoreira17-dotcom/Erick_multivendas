import React from 'react';
import { ArrowRight } from 'lucide-react';

export default function Hero({ data }) {
  const hero = data?.hero || {};

  return (
    <section id="home" className="pt-32 pb-20 px-6 max-w-7xl mx-auto flex flex-col md:flex-row items-center gap-12">
      <div className="flex-1 text-center md:text-left">
        <span className="inline-block px-4 py-1.5 rounded-full bg-sky-950/80 border border-sky-500/30 text-sky-400 text-xs font-semibold tracking-wide uppercase mb-6">
          Plataforma Premium de Educação
        </span>
        <h1 className="text-4xl md:text-6xl font-extrabold leading-tight text-white mb-6">
          {hero.title || 'Transforme seu conhecimento em novas oportunidades com o Marketing Digital.'}
        </h1>
        <p className="text-slate-400 text-lg md:text-xl mb-8 max-w-2xl">
          {hero.subtitle || 'Aprenda estratégias validadas para criar, escalar e dominar o mercado digital do zero.'}
        </p>
        <a 
          href={hero.buttonUrl || '#courses'} 
          className="inline-flex items-center gap-3 px-8 py-4 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-bold text-lg transition blue-glow"
        >
          {hero.buttonText || 'QUERO COMEÇAR AGORA'}
          <ArrowRight size={20} />
        </a>
      </div>

      <div className="flex-1 w-full">
        <div className="relative rounded-2xl overflow-hidden border border-slate-800 blue-glow">
          <img 
            src={hero.bannerUrl || 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80'} 
            alt="Império Digital Banner" 
            className="w-full h-80 md:h-[420px] object-cover"
          />
        </div>
      </div>
    </section>
  );
}
