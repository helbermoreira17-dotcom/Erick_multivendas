import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { MoveUp, MoveDown, Trash2, Plus, Save, Lock, Image as ImageIcon } from 'lucide-react';

export default function Admin() {
  const [token, setToken] = useState(localStorage.getItem('token') || '');
  const [password, setPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [siteData, setSiteData] = useState(null);
  const [activeTab, setActiveTab] = useState('content');

  const [newCourse, setNewCourse] = useState({
    title: '', description: '', price: 97, old_price: 197, discount_percentage: 50, promo_active: 1, image: '', checkout_url: ''
  });

  const [newFaq, setNewFaq] = useState({ question: '', answer: '' });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = () => {
    axios.get('http://localhost:5000/api/site-data')
      .then(res => setSiteData(res.data));
  };

  const handleLogin = (e) => {
    e.preventDefault();
    axios.post('http://localhost:5000/api/login', { password })
      .then(res => {
        setToken(res.data.token);
        localStorage.setItem('token', res.data.token);
      })
      .catch(() => alert('Senha incorreta!'));
  };

  const handleChangePassword = (e) => {
    e.preventDefault();
    axios.post('http://localhost:5000/api/change-password', { newPassword }, {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(() => alert('Senha alterada com sucesso!'))
    .catch(err => alert(err.response?.data?.error || 'Erro ao alterar'));
  };

  const saveSetting = (key, value) => {
    axios.post('http://localhost:5000/api/settings', { key, value }, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(() => fetchData());
  };

  const moveSection = (index, direction) => {
    const layout = [...siteData.layout];
    const targetIndex = index + direction;
    if (targetIndex < 0 || targetIndex >= layout.length) return;
    const temp = layout[index];
    layout[index] = layout[targetIndex];
    layout[targetIndex] = temp;
    saveSetting('layout', layout);
  };

  const handleFileUpload = (e, callback) => {
    const file = e.target.files[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('image', file);
    axios.post('http://localhost:5000/api/upload', formData, {
      headers: { 
        Authorization: `Bearer ${token}`,
        'Content-Type': 'multipart/form-data'
      }
    }).then(res => callback(res.data.url));
  };

  const addCourse = (e) => {
    e.preventDefault();
    axios.post('http://localhost:5000/api/courses', newCourse, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(() => {
      fetchData();
      setNewCourse({ title: '', description: '', price: 97, old_price: 197, discount_percentage: 50, promo_active: 1, image: '', checkout_url: '' });
    });
  };

  const deleteCourse = (id) => {
    axios.delete(`http://localhost:5000/api/courses/${id}`, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(() => fetchData());
  };

  const addFaq = (e) => {
    e.preventDefault();
    axios.post('http://localhost:5000/api/faqs', newFaq, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(() => {
      fetchData();
      setNewFaq({ question: '', answer: '' });
    });
  };

  const deleteFaq = (id) => {
    axios.delete(`http://localhost:5000/api/faqs/${id}`, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(() => fetchData());
  };

  if (!token) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6 text-white">
        <form onSubmit={handleLogin} className="bg-slate-900 border border-slate-800 p-8 rounded-2xl w-full max-w-md blue-glow">
          <h1 className="text-2xl font-black mb-6 text-center">Acesso Restrito CMS</h1>
          <div className="mb-4">
            <label className="text-sm font-semibold mb-2 block">Senha de Acesso</label>
            <input 
              type="password" 
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full p-3 bg-slate-950 border border-slate-800 rounded-lg text-white"
              placeholder="Digite sua senha..."
            />
          </div>
          <button type="submit" className="w-full py-3 bg-sky-600 font-bold rounded-lg hover:bg-sky-500 transition">
            Entrar no Painel
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col">
      <header className="bg-slate-900 border-b border-slate-800 p-4 px-8 flex justify-between items-center">
        <h1 className="text-xl font-black">Painel Administrativo - IMPÉRIO DIGITAL</h1>
        <button onClick={() => { localStorage.removeItem('token'); setToken(''); }} className="text-xs bg-red-600/20 text-red-400 px-4 py-2 rounded-lg border border-red-500/30">
          Sair
        </button>
      </header>

      <div className="flex-1 flex">
        <aside className="w-64 bg-slate-900/50 border-r border-slate-800 p-6 flex flex-col gap-2">
          <button onClick={() => setActiveTab('content')} className={`p-3 text-left rounded-lg font-semibold ${activeTab === 'content' ? 'bg-sky-600' : 'hover:bg-slate-800'}`}>
            Textos & Banner
          </button>
          <button onClick={() => setActiveTab('courses')} className={`p-3 text-left rounded-lg font-semibold ${activeTab === 'courses' ? 'bg-sky-600' : 'hover:bg-slate-800'}`}>
            Cursos & Preços
          </button>
          <button onClick={() => setActiveTab('layout')} className={`p-3 text-left rounded-lg font-semibold ${activeTab === 'layout' ? 'bg-sky-600' : 'hover:bg-slate-800'}`}>
            Organizar Seções
          </button>
          <button onClick={() => setActiveTab('faqs')} className={`p-3 text-left rounded-lg font-semibold ${activeTab === 'faqs' ? 'bg-sky-600' : 'hover:bg-slate-800'}`}>
            Perguntas (FAQ)
          </button>
          <button onClick={() => setActiveTab('security')} className={`p-3 text-left rounded-lg font-semibold ${activeTab === 'security' ? 'bg-sky-600' : 'hover:bg-slate-800'}`}>
            Segurança
          </button>
        </aside>

        <main className="flex-1 p-8 overflow-y-auto max-w-4xl">
          {activeTab === 'content' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Hero & Conteúdo Principal</h2>
              <div>
                <label className="block text-sm mb-2">Título do Hero</label>
                <input 
                  type="text" 
                  value={siteData?.hero?.title || ''} 
                  onChange={e => saveSetting('hero', { ...siteData.hero, title: e.target.value })}
                  className="w-full p-3 bg-slate-900 border border-slate-800 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-sm mb-2">Subtítulo</label>
                <textarea 
                  value={siteData?.hero?.subtitle || ''} 
                  onChange={e => saveSetting('hero', { ...siteData.hero, subtitle: e.target.value })}
                  className="w-full p-3 bg-slate-900 border border-slate-800 rounded-lg h-24"
                />
              </div>
              <div>
                <label className="block text-sm mb-2">Banner do Hero (URL ou Upload)</label>
                <input 
                  type="text" 
                  value={siteData?.hero?.bannerUrl || ''} 
                  onChange={e => saveSetting('hero', { ...siteData.hero, bannerUrl: e.target.value })}
                  className="w-full p-3 bg-slate-900 border border-slate-800 rounded-lg mb-2"
                />
                <input 
                  type="file" 
                  onChange={e => handleFileUpload(e, (url) => saveSetting('hero', { ...siteData.hero, bannerUrl: url }))}
                  className="text-sm text-slate-400"
                />
              </div>
            </div>
          )}

          {activeTab === 'courses' && (
            <div className="space-y-8">
              <h2 className="text-2xl font-bold">Gerenciar Cursos</h2>
              
              <form onSubmit={addCourse} className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
                <h3 className="font-bold text-lg mb-2">Cadastrar Novo Curso</h3>
                <input 
                  type="text" placeholder="Título" value={newCourse.title} 
                  onChange={e => setNewCourse({...newCourse, title: e.target.value})} 
                  className="w-full p-3 bg-slate-950 border border-slate-800 rounded-lg" required
                />
                <textarea 
                  placeholder="Descrição" value={newCourse.description} 
                  onChange={e => setNewCourse({...newCourse, description: e.target.value})} 
                  className="w-full p-3 bg-slate-950 border border-slate-800 rounded-lg" required
                />
                <div className="grid grid-cols-2 gap-4">
                  <input 
                    type="number" placeholder="Preço Atual" value={newCourse.price} 
                    onChange={e => setNewCourse({...newCourse, price: parseFloat(e.target.value)})} 
                    className="p-3 bg-slate-950 border border-slate-800 rounded-lg" required
                  />
                  <input 
                    type="number" placeholder="Preço Antigo" value={newCourse.old_price} 
                    onChange={e => setNewCourse({...newCourse, old_price: parseFloat(e.target.value)})} 
                    className="p-3 bg-slate-950 border border-slate-800 rounded-lg"
                  />
                </div>
                <input 
                  type="text" placeholder="Link do Checkout" value={newCourse.checkout_url} 
                  onChange={e => setNewCourse({...newCourse, checkout_url: e.target.value})} 
                  className="w-full p-3 bg-slate-950 border border-slate-800 rounded-lg" required
                />
                <div>
                  <label className="block text-sm mb-1">Imagem do Curso</label>
                  <input 
                    type="file" 
                    onChange={e => handleFileUpload(e, (url) => setNewCourse({...newCourse, image: url}))}
                    className="text-sm text-slate-400"
                  />
                </div>
                <button type="submit" className="px-6 py-3 bg-sky-600 font-bold rounded-lg">Adicionar Curso</button>
              </form>

              <div className="space-y-4">
                {siteData?.courses?.map(course => (
                  <div key={course.id} className="p-4 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
                    <div>
                      <h4 className="font-bold">{course.title}</h4>
                      <p className="text-sm text-slate-400">R$ {course.price}</p>
                    </div>
                    <button onClick={() => deleteCourse(course.id)} className="p-2 bg-red-600/20 text-red-400 rounded-lg hover:bg-red-600/40">
                      <Trash2 size={18} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'layout' && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Reordenar Seções do Site</h2>
              <div className="space-y-3">
                {siteData?.layout?.map((sectionKey, index) => (
                  <div key={sectionKey} className="p-4 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
                    <span className="font-bold uppercase tracking-wider text-sky-400">{sectionKey}</span>
                    <div className="flex gap-2">
                      <button onClick={() => moveSection(index, -1)} className="p-2 bg-slate-800 rounded-lg hover:bg-slate-700">
                        <MoveUp size={18} />
                      </button>
                      <button onClick={() => moveSection(index, 1)} className="p-2 bg-slate-800 rounded-lg hover:bg-slate-700">
                        <MoveDown size={18} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'faqs' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Gerenciar FAQ</h2>
              <form onSubmit={addFaq} className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
                <input 
                  type="text" placeholder="Pergunta" value={newFaq.question} 
                  onChange={e => setNewFaq({...newFaq, question: e.target.value})} 
                  className="w-full p-3 bg-slate-950 border border-slate-800 rounded-lg" required
                />
                <textarea 
                  placeholder="Resposta" value={newFaq.answer} 
                  onChange={e => setNewFaq({...newFaq, answer: e.target.value})} 
                  className="w-full p-3 bg-slate-950 border border-slate-800 rounded-lg" required
                />
                <button type="submit" className="px-6 py-3 bg-sky-600 font-bold rounded-lg">Adicionar FAQ</button>
              </form>

              <div className="space-y-3">
                {siteData?.faqs?.map(faq => (
                  <div key={faq.id} className="p-4 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
                    <div>
                      <h4 className="font-bold">{faq.question}</h4>
                      <p className="text-sm text-slate-400">{faq.answer}</p>
                    </div>
                    <button onClick={() => deleteFaq(faq.id)} className="p-2 bg-red-600/20 text-red-400 rounded-lg">
                      <Trash2 size={18} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Segurança & Acesso</h2>
              <form onSubmit={handleChangePassword} className="bg-slate-900 p-6 rounded-xl border border-slate-800 max-w-md space-y-4">
                <div>
                  <label className="block text-sm mb-2">Nova Senha</label>
                  <input 
                    type="password" 
                    value={newPassword}
                    onChange={e => setNewPassword(e.target.value)}
                    className="w-full p-3 bg-slate-950 border border-slate-800 rounded-lg"
                    placeholder="Digite a nova senha..."
                    required
                  />
                </div>
                <button type="submit" className="w-full py-3 bg-sky-600 font-bold rounded-lg">
                  Atualizar Senha
                </button>
              </form>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
