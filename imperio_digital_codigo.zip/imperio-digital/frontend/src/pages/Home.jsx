import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Header from '../components/Header';
import Hero from '../components/Hero';
import Benefits from '../components/Benefits';
import Courses from '../components/Courses';
import CTA from '../components/CTA';
import FAQ from '../components/FAQ';
import Footer from '../components/Footer';

export default function Home() {
  const [siteData, setSiteData] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:5000/api/site-data')
      .then(res => setSiteData(res.data))
      .catch(err => console.error('Erro ao carregar dados:', err));
  }, []);

  if (!siteData) return <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">Carregando Império Digital...</div>;

  const sectionMap = {
    hero: <Hero key="hero" data={siteData} />,
    benefits: <Benefits key="benefits" />,
    courses: <Courses key="courses" data={siteData} />,
    cta: <CTA key="cta" data={siteData} />,
    faq: <FAQ key="faq" data={siteData} />
  };

  const layout = siteData.layout || ['hero', 'benefits', 'courses', 'cta', 'faq'];

  return (
    <div className="bg-slate-950 text-white min-h-screen font-sans">
      <Header data={siteData} />
      <main>
        {layout.map(sectionKey => sectionMap[sectionKey])}
      </main>
      <Footer data={siteData} />
    </div>
  );
}
