/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        darkBg: '#030712',
        cardBg: '#0f172a',
        accentBlue: '#0284c7',
        glowBlue: '#38bdf8'
      }
    },
  },
  plugins: [],
}
